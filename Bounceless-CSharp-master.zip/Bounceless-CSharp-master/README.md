#  bounceless-csharp

please visit the page for more information about "bulk" api http://www.bounceless.io/docs/net
& also about "one by one" api http://www.bounceless.io/docs/net
